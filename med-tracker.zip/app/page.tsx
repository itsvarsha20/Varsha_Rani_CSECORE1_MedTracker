import { redirect } from "next/navigation"
import { AuthForm } from "@/components/auth-form"

export default function Home() {
  // Check if user is logged in from localStorage (client-side only)
  if (typeof window !== "undefined") {
    const user = localStorage.getItem("med-tracker-user")
    if (user) {
      redirect("/dashboard")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-950">
      <div className="container flex flex-col items-center justify-center min-h-screen px-4 py-12 mx-auto">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-blue-600 dark:text-blue-400">Med-tracker</h1>
            <p className="mt-2 text-gray-600 dark:text-gray-400">Your personal medication reminder system</p>
          </div>
          <AuthForm />
        </div>
      </div>
    </div>
  )
}
