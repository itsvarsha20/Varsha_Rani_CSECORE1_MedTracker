"use client"

import { useState } from "react"
import { format } from "date-fns"
import { CalendarIcon, FileText, Plus, Stethoscope, Syringe, TestTube } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"

// Sample medical history data
const initialRecords = [
  {
    id: "1",
    type: "appointment",
    title: "Annual Physical",
    date: new Date(2023, 3, 15),
    provider: "Dr. Sarah Johnson",
    location: "City Medical Center",
    notes: "Routine checkup, all vitals normal.",
    followUp: "Next annual physical in 12 months",
  },
  {
    id: "2",
    type: "test",
    title: "Blood Work Panel",
    date: new Date(2023, 2, 10),
    provider: "Quest Diagnostics",
    location: "Downtown Lab",
    notes: "Comprehensive metabolic panel and lipid profile.",
    followUp: "Results to be reviewed at next appointment",
  },
  {
    id: "3",
    type: "vaccination",
    title: "Flu Vaccine",
    date: new Date(2023, 9, 5),
    provider: "Walgreens Pharmacy",
    location: "Walgreens #1234",
    notes: "Annual influenza vaccination.",
    followUp: "None required",
  },
  {
    id: "4",
    type: "procedure",
    title: "Dental Cleaning",
    date: new Date(2023, 6, 20),
    provider: "Dr. Michael Chen",
    location: "Bright Smile Dental",
    notes: "Routine cleaning and examination.",
    followUp: "Next cleaning in 6 months",
  },
]

export default function MedicalHistoryPage() {
  const [records, setRecords] = useState(initialRecords)
  const [open, setOpen] = useState(false)
  const [newRecord, setNewRecord] = useState({
    type: "",
    title: "",
    date: new Date(),
    provider: "",
    location: "",
    notes: "",
    followUp: "",
  })

  const handleAddRecord = () => {
    const id = (records.length + 1).toString()

    setRecords([
      {
        ...newRecord,
        id,
      },
      ...records,
    ])

    setNewRecord({
      type: "",
      title: "",
      date: new Date(),
      provider: "",
      location: "",
      notes: "",
      followUp: "",
    })

    setOpen(false)
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "appointment":
        return <Stethoscope className="h-4 w-4" />
      case "test":
        return <TestTube className="h-4 w-4" />
      case "vaccination":
        return <Syringe className="h-4 w-4" />
      case "procedure":
        return <FileText className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "appointment":
        return "text-blue-500 bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800"
      case "test":
        return "text-purple-500 bg-purple-50 dark:bg-purple-950/50 border-purple-200 dark:border-purple-800"
      case "vaccination":
        return "text-green-500 bg-green-50 dark:bg-green-950/50 border-green-200 dark:border-green-800"
      case "procedure":
        return "text-orange-500 bg-orange-50 dark:bg-orange-950/50 border-orange-200 dark:border-orange-800"
      default:
        return "text-gray-500 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
    }
  }

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Medical History</h1>
          <p className="text-muted-foreground">Track your medical appointments, tests, and procedures</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Record
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Add Medical Record</DialogTitle>
              <DialogDescription>Enter the details of your medical record</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="type">Record Type</Label>
                <Select value={newRecord.type} onValueChange={(value) => setNewRecord({ ...newRecord, type: value })}>
                  <SelectTrigger id="type">
                    <SelectValue placeholder="Select record type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="appointment">Appointment</SelectItem>
                    <SelectItem value="test">Test/Lab Work</SelectItem>
                    <SelectItem value="vaccination">Vaccination</SelectItem>
                    <SelectItem value="procedure">Procedure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={newRecord.title}
                  onChange={(e) => setNewRecord({ ...newRecord, title: e.target.value })}
                  placeholder="e.g., Annual Physical"
                />
              </div>
              <div className="space-y-2">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !newRecord.date && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newRecord.date ? format(newRecord.date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={newRecord.date}
                      onSelect={(date) => date && setNewRecord({ ...newRecord, date })}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="provider">Provider</Label>
                  <Input
                    id="provider"
                    value={newRecord.provider}
                    onChange={(e) => setNewRecord({ ...newRecord, provider: e.target.value })}
                    placeholder="e.g., Dr. Smith"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={newRecord.location}
                    onChange={(e) => setNewRecord({ ...newRecord, location: e.target.value })}
                    placeholder="e.g., City Hospital"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={newRecord.notes}
                  onChange={(e) => setNewRecord({ ...newRecord, notes: e.target.value })}
                  placeholder="Additional details about this record"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="followUp">Follow-up</Label>
                <Input
                  id="followUp"
                  value={newRecord.followUp}
                  onChange={(e) => setNewRecord({ ...newRecord, followUp: e.target.value })}
                  placeholder="e.g., Next appointment in 6 months"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddRecord}>
                Add Record
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Medical Timeline</CardTitle>
          <CardDescription>A chronological record of your medical events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative space-y-8 before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-300 dark:before:via-gray-700 before:to-transparent">
            {records.map((record, index) => (
              <div key={record.id} className="relative flex items-start md:justify-center">
                <div className="absolute left-0 md:left-1/2 ml-2.5 md:ml-0 md:-translate-x-1/2 top-5 h-10 w-10 rounded-full border flex items-center justify-center bg-background shadow-md">
                  {getTypeIcon(record.type)}
                </div>
                <div className="ml-16 md:ml-0 md:max-w-md md:mr-0 md:pr-0 md:w-1/2 md:text-right md:mr-10 lg:mr-16">
                  <div className={cn("p-4 rounded-lg border", getTypeColor(record.type))}>
                    <div className="flex flex-col">
                      <h3 className="font-semibold">{record.title}</h3>
                      <time className="text-sm text-gray-600 dark:text-gray-400">
                        {format(record.date, "MMMM d, yyyy")}
                      </time>
                      <div className="mt-2 space-y-1 text-sm">
                        <p>
                          <span className="font-medium">Provider:</span> {record.provider}
                        </p>
                        <p>
                          <span className="font-medium">Location:</span> {record.location}
                        </p>
                        {record.notes && (
                          <p>
                            <span className="font-medium">Notes:</span> {record.notes}
                          </p>
                        )}
                        {record.followUp && (
                          <p>
                            <span className="font-medium">Follow-up:</span> {record.followUp}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                {index % 2 === 1 && <div className="hidden md:block md:w-1/2 md:pl-10 lg:pl-16"></div>}
                {index % 2 === 0 && index > 0 && <div className="hidden md:block md:w-1/2"></div>}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
