"use client"

import { useState } from "react"
import { format, subDays } from "date-fns"
import { Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdherenceChart } from "@/components/adherence-chart"
import { MedicationUsageChart } from "@/components/medication-usage-chart"

export default function ReportsPage() {
  const [timeRange, setTimeRange] = useState("30")
  const [startDate, setStartDate] = useState<Date>(subDays(new Date(), 30))

  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value)

    switch (value) {
      case "7":
        setStartDate(subDays(new Date(), 7))
        break
      case "30":
        setStartDate(subDays(new Date(), 30))
        break
      case "90":
        setStartDate(subDays(new Date(), 90))
        break
      case "180":
        setStartDate(subDays(new Date(), 180))
        break
      case "365":
        setStartDate(subDays(new Date(), 365))
        break
    }
  }

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">Analyze your medication adherence and usage patterns</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={handleTimeRangeChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
              <SelectItem value="180">Last 6 months</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Adherence</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <p className="text-xs text-muted-foreground">+2% from previous period</p>
            <div className="mt-4 h-1 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div className="bg-blue-500 h-full rounded-full" style={{ width: "85%" }}></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Doses Taken</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">127</div>
            <p className="text-xs text-muted-foreground">Out of 150 scheduled doses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Missed Doses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">23</div>
            <p className="text-xs text-muted-foreground">15% of scheduled doses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Perfect Days</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">80% of total days</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="adherence" className="space-y-4">
        <TabsList>
          <TabsTrigger value="adherence">Adherence</TabsTrigger>
          <TabsTrigger value="usage">Medication Usage</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="adherence" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Adherence Over Time</CardTitle>
              <CardDescription>
                Your medication adherence from {format(startDate, "MMMM d, yyyy")} to{" "}
                {format(new Date(), "MMMM d, yyyy")}
              </CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <AdherenceChart timeRange={timeRange} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Medication Usage</CardTitle>
              <CardDescription>Breakdown of your medication usage by type</CardDescription>
            </CardHeader>
            <CardContent>
              <MedicationUsageChart />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Adherence Trends</CardTitle>
              <CardDescription>Patterns and insights from your medication data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Key Insights</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                      <p className="text-sm">Your adherence is highest in the morning (92%)</p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                      <p className="text-sm">You tend to miss evening doses more frequently (75% adherence)</p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-blue-500"></div>
                      <p className="text-sm">Weekends show lower adherence compared to weekdays</p>
                    </li>
                  </ul>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Recommendations</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-green-500"></div>
                      <p className="text-sm">Set evening reminders to improve your evening dose adherence</p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-green-500"></div>
                      <p className="text-sm">Create a weekend routine to maintain consistency</p>
                    </li>
                    <li className="flex items-start">
                      <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-green-500"></div>
                      <p className="text-sm">Consider using pill organizers for better tracking</p>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
