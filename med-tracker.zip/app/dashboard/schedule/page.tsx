"use client"

import { useState } from "react"
import { format, addDays, startOfWeek, addWeeks, subWeeks } from "date-fns"
import { CalendarIcon, ChevronLeft, ChevronRight, Clock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"

// Sample medication schedule data
const medicationSchedule = [
  {
    id: "1",
    name: "Lisinopril",
    dosage: "10mg",
    time: "08:00 AM",
    days: [0, 1, 2, 3, 4, 5, 6], // All days
  },
  {
    id: "2",
    name: "Metformin",
    dosage: "500mg",
    time: "08:00 AM",
    days: [0, 1, 2, 3, 4, 5, 6], // All days
  },
  {
    id: "3",
    name: "Metformin",
    dosage: "500mg",
    time: "08:00 PM",
    days: [0, 1, 2, 3, 4, 5, 6], // All days
  },
  {
    id: "4",
    name: "Atorvastatin",
    dosage: "20mg",
    time: "08:00 PM",
    days: [0, 1, 2, 3, 4, 5, 6], // All days
  },
  {
    id: "5",
    name: "Vitamin D",
    dosage: "1000 IU",
    time: "12:00 PM",
    days: [0, 3], // Sunday and Wednesday
  },
]

export default function SchedulePage() {
  const [date, setDate] = useState<Date>(new Date())
  const [weekStart, setWeekStart] = useState<Date>(startOfWeek(new Date(), { weekStartsOn: 0 }))

  const nextWeek = () => {
    setWeekStart(addWeeks(weekStart, 1))
  }

  const prevWeek = () => {
    setWeekStart(subWeeks(weekStart, 1))
  }

  // Generate week days
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))

  // Group medications by time
  const getMedicationsByTime = () => {
    const timeGroups: Record<string, typeof medicationSchedule> = {}

    medicationSchedule.forEach((med) => {
      if (!timeGroups[med.time]) {
        timeGroups[med.time] = []
      }
      timeGroups[med.time].push(med)
    })

    // Sort by time
    return Object.entries(timeGroups).sort(([timeA], [timeB]) => {
      return new Date(`1970/01/01 ${timeA}`).getTime() - new Date(`1970/01/01 ${timeB}`).getTime()
    })
  }

  // Get medications for a specific day
  const getMedicationsForDay = (day: Date) => {
    const dayOfWeek = day.getDay() // 0 for Sunday, 1 for Monday, etc.

    return medicationSchedule.filter((med) => med.days.includes(dayOfWeek))
  }

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Medication Schedule</h1>
          <p className="text-muted-foreground">View and manage your medication schedule</p>
        </div>
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant={"outline"}
                className={cn("w-[240px] justify-start text-left font-normal", !date && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar mode="single" selected={date} onSelect={(date) => date && setDate(date)} initialFocus />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <Tabs defaultValue="daily" className="space-y-4">
        <TabsList>
          <TabsTrigger value="daily">Daily View</TabsTrigger>
          <TabsTrigger value="weekly">Weekly View</TabsTrigger>
          <TabsTrigger value="list">List View</TabsTrigger>
        </TabsList>

        {/* Daily View */}
        <TabsContent value="daily" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Medications for {format(date, "EEEE, MMMM d, yyyy")}</CardTitle>
              <CardDescription>Your scheduled medications for today</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {getMedicationsByTime().map(([time, meds]) => (
                  <div key={time} className="space-y-2">
                    <h3 className="flex items-center text-sm font-medium text-muted-foreground">
                      <Clock className="mr-2 h-4 w-4" />
                      {time}
                    </h3>
                    <div className="grid gap-2">
                      {meds
                        .filter((med) => med.days.includes(date.getDay()))
                        .map((med) => (
                          <div key={med.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                            <div>
                              <h4 className="font-medium">{med.name}</h4>
                              <p className="text-sm text-muted-foreground">{med.dosage}</p>
                            </div>
                            <Button size="sm" variant="outline">
                              Mark as Taken
                            </Button>
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Weekly View */}
        <TabsContent value="weekly" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center">
              <div className="flex-1">
                <CardTitle>Week of {format(weekStart, "MMMM d, yyyy")}</CardTitle>
                <CardDescription>Your medication schedule for the week</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={prevWeek}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={nextWeek}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-4">
                {weekDays.map((day) => (
                  <div key={day.toString()} className="space-y-2">
                    <div className="text-center">
                      <div className="text-sm font-medium">{format(day, "EEE")}</div>
                      <div
                        className={cn(
                          "flex items-center justify-center rounded-full mx-auto w-8 h-8 text-sm",
                          format(day, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd")
                            ? "bg-blue-600 text-white"
                            : "text-muted-foreground",
                        )}
                      >
                        {format(day, "d")}
                      </div>
                    </div>
                    <div className="space-y-1">
                      {getMedicationsForDay(day).map((med) => (
                        <div
                          key={med.id}
                          className="p-2 text-xs rounded-md bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800"
                        >
                          <div className="font-medium">{med.name}</div>
                          <div className="flex justify-between text-muted-foreground">
                            <span>{med.dosage}</span>
                            <span>{med.time}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* List View */}
        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Medications</CardTitle>
              <CardDescription>Complete list of your medication schedule</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {medicationSchedule.map((med) => (
                  <div key={med.id} className="p-4 rounded-lg border bg-card">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">
                          {med.name} - {med.dosage}
                        </h3>
                        <p className="text-sm text-muted-foreground">{med.time}</p>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {med.days.length === 7 ? (
                          <span>Daily</span>
                        ) : (
                          <span>
                            {med.days.map((day) => ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][day]).join(", ")}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
