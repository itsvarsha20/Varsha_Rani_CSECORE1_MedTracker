"use client"

import { useState } from "react"
import { format } from "date-fns"
import { CalendarIcon, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"
import { MedicationCard } from "@/components/medication-card"

// Sample medication data
const initialMedications = [
  {
    id: "1",
    name: "Lisinopril",
    dosage: "10mg",
    frequency: "Once daily",
    time: ["08:00 AM"],
    startDate: new Date(2023, 0, 15),
    endDate: new Date(2023, 11, 15),
    instructions: "Take with food",
    color: "blue",
  },
  {
    id: "2",
    name: "Metformin",
    dosage: "500mg",
    frequency: "Twice daily",
    time: ["08:00 AM", "08:00 PM"],
    startDate: new Date(2023, 1, 10),
    endDate: new Date(2023, 10, 10),
    instructions: "Take with meals",
    color: "green",
  },
  {
    id: "3",
    name: "Atorvastatin",
    dosage: "20mg",
    frequency: "Once daily",
    time: ["08:00 PM"],
    startDate: new Date(2023, 2, 5),
    endDate: new Date(2023, 9, 5),
    instructions: "Take at bedtime",
    color: "purple",
  },
]

export default function MedicationsPage() {
  const [medications, setMedications] = useState(initialMedications)
  const [open, setOpen] = useState(false)
  const [newMedication, setNewMedication] = useState({
    name: "",
    dosage: "",
    frequency: "",
    time: ["08:00 AM"],
    startDate: new Date(),
    endDate: new Date(new Date().setMonth(new Date().getMonth() + 3)),
    instructions: "",
  })

  const handleAddMedication = () => {
    const id = (medications.length + 1).toString()
    const colors = ["blue", "green", "purple", "red", "orange", "teal"]
    const randomColor = colors[Math.floor(Math.random() * colors.length)]

    setMedications([
      ...medications,
      {
        ...newMedication,
        id,
        color: randomColor,
      },
    ])

    setNewMedication({
      name: "",
      dosage: "",
      frequency: "",
      time: ["08:00 AM"],
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 3)),
      instructions: "",
    })

    setOpen(false)
  }

  const handleTimeChange = (index: number, value: string) => {
    const newTimes = [...newMedication.time]
    newTimes[index] = value
    setNewMedication({ ...newMedication, time: newTimes })
  }

  const addTimeSlot = () => {
    setNewMedication({
      ...newMedication,
      time: [...newMedication.time, "12:00 PM"],
    })
  }

  const removeTimeSlot = (index: number) => {
    const newTimes = [...newMedication.time]
    newTimes.splice(index, 1)
    setNewMedication({ ...newMedication, time: newTimes })
  }

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Medications</h1>
          <p className="text-muted-foreground">Manage your medications and dosage schedules</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Medication
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Add New Medication</DialogTitle>
              <DialogDescription>Enter the details of your new medication</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Medication Name</Label>
                  <Input
                    id="name"
                    value={newMedication.name}
                    onChange={(e) => setNewMedication({ ...newMedication, name: e.target.value })}
                    placeholder="e.g., Lisinopril"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dosage">Dosage</Label>
                  <Input
                    id="dosage"
                    value={newMedication.dosage}
                    onChange={(e) => setNewMedication({ ...newMedication, dosage: e.target.value })}
                    placeholder="e.g., 10mg"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="frequency">Frequency</Label>
                <Select
                  value={newMedication.frequency}
                  onValueChange={(value) => setNewMedication({ ...newMedication, frequency: value })}
                >
                  <SelectTrigger id="frequency">
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Once daily">Once daily</SelectItem>
                    <SelectItem value="Twice daily">Twice daily</SelectItem>
                    <SelectItem value="Three times daily">Three times daily</SelectItem>
                    <SelectItem value="Every other day">Every other day</SelectItem>
                    <SelectItem value="Weekly">Weekly</SelectItem>
                    <SelectItem value="As needed">As needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Time(s)</Label>
                <div className="space-y-2">
                  {newMedication.time.map((time, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Select value={time} onValueChange={(value) => handleTimeChange(index, value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="06:00 AM">06:00 AM</SelectItem>
                          <SelectItem value="07:00 AM">07:00 AM</SelectItem>
                          <SelectItem value="08:00 AM">08:00 AM</SelectItem>
                          <SelectItem value="09:00 AM">09:00 AM</SelectItem>
                          <SelectItem value="12:00 PM">12:00 PM</SelectItem>
                          <SelectItem value="01:00 PM">01:00 PM</SelectItem>
                          <SelectItem value="06:00 PM">06:00 PM</SelectItem>
                          <SelectItem value="08:00 PM">08:00 PM</SelectItem>
                          <SelectItem value="10:00 PM">10:00 PM</SelectItem>
                        </SelectContent>
                      </Select>
                      {newMedication.time.length > 1 && (
                        <Button variant="ghost" size="icon" onClick={() => removeTimeSlot(index)}>
                          <span className="sr-only">Remove time</span>
                          <span aria-hidden>×</span>
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button type="button" variant="outline" size="sm" className="mt-2" onClick={addTimeSlot}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Time
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !newMedication.startDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {newMedication.startDate ? format(newMedication.startDate, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={newMedication.startDate}
                        onSelect={(date) => date && setNewMedication({ ...newMedication, startDate: date })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="space-y-2">
                  <Label>End Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !newMedication.endDate && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {newMedication.endDate ? format(newMedication.endDate, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={newMedication.endDate}
                        onSelect={(date) => date && setNewMedication({ ...newMedication, endDate: date })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="instructions">Special Instructions</Label>
                <Textarea
                  id="instructions"
                  value={newMedication.instructions}
                  onChange={(e) =>
                    setNewMedication({
                      ...newMedication,
                      instructions: e.target.value,
                    })
                  }
                  placeholder="e.g., Take with food"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddMedication}>
                Add Medication
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {medications.map((medication) => (
          <MedicationCard key={medication.id} medication={medication} />
        ))}
      </div>
    </div>
  )
}
