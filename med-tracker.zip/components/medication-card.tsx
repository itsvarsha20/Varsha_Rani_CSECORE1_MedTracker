"use client"

import { useState } from "react"
import { format } from "date-fns"
import { CheckCircle, Clock, Info } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { cn } from "@/lib/utils"

interface MedicationCardProps {
  medication: {
    id: string
    name: string
    dosage: string
    frequency: string
    time: string[]
    startDate: Date
    endDate: Date
    instructions: string
    color: string
  }
}

export function MedicationCard({ medication }: MedicationCardProps) {
  const [showDetails, setShowDetails] = useState(false)

  // Get color classes based on medication color
  const getColorClasses = (color: string) => {
    const colorMap: Record<string, { bg: string; border: string; text: string }> = {
      blue: {
        bg: "bg-blue-50 dark:bg-blue-950/50",
        border: "border-blue-200 dark:border-blue-800",
        text: "text-blue-600 dark:text-blue-400",
      },
      green: {
        bg: "bg-green-50 dark:bg-green-950/50",
        border: "border-green-200 dark:border-green-800",
        text: "text-green-600 dark:text-green-400",
      },
      purple: {
        bg: "bg-purple-50 dark:bg-purple-950/50",
        border: "border-purple-200 dark:border-purple-800",
        text: "text-purple-600 dark:text-purple-400",
      },
      red: {
        bg: "bg-red-50 dark:bg-red-950/50",
        border: "border-red-200 dark:border-red-800",
        text: "text-red-600 dark:text-red-400",
      },
      orange: {
        bg: "bg-orange-50 dark:bg-orange-950/50",
        border: "border-orange-200 dark:border-orange-800",
        text: "text-orange-600 dark:text-orange-400",
      },
      teal: {
        bg: "bg-teal-50 dark:bg-teal-950/50",
        border: "border-teal-200 dark:border-teal-800",
        text: "text-teal-600 dark:text-teal-400",
      },
    }

    return colorMap[color] || colorMap.blue
  }

  const colorClasses = getColorClasses(medication.color)

  return (
    <>
      <Card
        className={cn(
          "overflow-hidden transition-all duration-300 hover:shadow-md transform hover:-translate-y-1 group",
          colorClasses.bg,
          colorClasses.border,
        )}
      >
        <CardHeader className={cn("pb-2", colorClasses.text)}>
          <CardTitle className="flex justify-between items-center">
            <span>{medication.name}</span>
            <span className="text-sm font-normal">{medication.dosage}</span>
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-400">{medication.frequency}</CardDescription>
        </CardHeader>
        <CardContent className="pb-2">
          <div className="space-y-2">
            <div className="flex flex-wrap gap-2">
              {medication.time.map((time, index) => (
                <div
                  key={index}
                  className="flex items-center px-2 py-1 rounded-full bg-white dark:bg-gray-800 border text-sm"
                >
                  <Clock className="h-3 w-3 mr-1" />
                  {time}
                </div>
              ))}
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {format(medication.startDate, "MMM d, yyyy")} - {format(medication.endDate, "MMM d, yyyy")}
            </p>
          </div>
        </CardContent>
        <CardFooter className="pt-0 flex justify-between">
          <Button
            variant="ghost"
            size="sm"
            className={cn("text-sm", colorClasses.text)}
            onClick={() => setShowDetails(true)}
          >
            <Info className="h-4 w-4 mr-1" />
            Details
          </Button>
          <Button variant="outline" size="sm" className="text-sm">
            <CheckCircle className="h-4 w-4 mr-1" />
            Take Now
          </Button>
        </CardFooter>
      </Card>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className={cn("text-xl", colorClasses.text)}>
              {medication.name} - {medication.dosage}
            </DialogTitle>
            <DialogDescription>Medication details and instructions</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium mb-1">Frequency</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">{medication.frequency}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium mb-1">Dosage</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">{medication.dosage}</p>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Schedule</h4>
              <div className="flex flex-wrap gap-2">
                {medication.time.map((time, index) => (
                  <div
                    key={index}
                    className="flex items-center px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-sm"
                  >
                    <Clock className="h-3 w-3 mr-1" />
                    {time}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Duration</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                From {format(medication.startDate, "MMMM d, yyyy")} to {format(medication.endDate, "MMMM d, yyyy")}
              </p>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Special Instructions</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {medication.instructions || "No special instructions provided."}
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
