"use client"

import { Line, LineChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "@/components/ui/chart"

// Generate sample data based on time range
const generateData = (timeRange: string) => {
  const days = Number.parseInt(timeRange)
  const data = []

  for (let i = 0; i < days; i++) {
    const date = new Date()
    date.setDate(date.getDate() - (days - i - 1))

    // Generate a random adherence value between 70 and 100
    const adherence = Math.floor(Math.random() * 30) + 70

    data.push({
      date: date.toISOString().split("T")[0],
      adherence,
    })
  }

  return data
}

interface AdherenceChartProps {
  timeRange: string
}

export function AdherenceChart({ timeRange }: AdherenceChartProps) {
  const data = generateData(timeRange)

  return (
    <ResponsiveContainer width="100%" height={350}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis
          dataKey="date"
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => {
            const date = new Date(value)
            // Format based on time range
            if (Number.parseInt(timeRange) <= 14) {
              return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
            } else if (Number.parseInt(timeRange) <= 90) {
              return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
            } else {
              return date.toLocaleDateString("en-US", { month: "short" })
            }
          }}
          // Show fewer ticks for larger time ranges
          interval={Number.parseInt(timeRange) > 30 ? Math.floor(Number.parseInt(timeRange) / 30) : 0}
        />
        <YAxis
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          domain={[0, 100]}
          tickFormatter={(value) => `${value}%`}
        />
        <Tooltip
          formatter={(value: number) => [`${value}%`, "Adherence"]}
          labelFormatter={(label) => {
            const date = new Date(label)
            return date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })
          }}
        />
        <Line
          type="monotone"
          dataKey="adherence"
          stroke="#4f46e5"
          strokeWidth={2}
          dot={{ r: 0 }}
          activeDot={{ r: 6, strokeWidth: 0 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
