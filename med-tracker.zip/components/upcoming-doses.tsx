"use client"

import { useState } from "react"
import { CheckCircle2, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

// Sample data for upcoming doses
const initialDoses = [
  {
    id: "1",
    name: "Lisinopril",
    dosage: "10mg",
    time: "08:00 AM",
    taken: true,
    timestamp: "07:58 AM",
  },
  {
    id: "2",
    name: "Metformin",
    dosage: "500mg",
    time: "12:00 PM",
    taken: false,
    timestamp: null,
  },
  {
    id: "3",
    name: "Atorvastatin",
    dosage: "20mg",
    time: "08:00 PM",
    taken: false,
    timestamp: null,
  },
]

export function UpcomingDoses() {
  const [doses, setDoses] = useState(initialDoses)

  const markAsTaken = (id: string) => {
    setDoses(
      doses.map((dose) =>
        dose.id === id
          ? {
              ...dose,
              taken: true,
              timestamp: new Date().toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              }),
            }
          : dose,
      ),
    )
  }

  return (
    <div className="space-y-4">
      {doses.map((dose) => (
        <div
          key={dose.id}
          className={cn(
            "flex items-center justify-between p-3 rounded-lg border transition-all",
            dose.taken
              ? "bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800"
              : "bg-white dark:bg-gray-950",
          )}
        >
          <div className="flex items-center gap-3">
            {dose.taken ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : (
              <Clock className="h-5 w-5 text-blue-500" />
            )}
            <div>
              <h4 className="font-medium">
                {dose.name} - {dose.dosage}
              </h4>
              <p className="text-sm text-muted-foreground">{dose.time}</p>
              {dose.taken && dose.timestamp && (
                <p className="text-xs text-green-600 dark:text-green-400">Taken at {dose.timestamp}</p>
              )}
            </div>
          </div>
          {!dose.taken && (
            <Button size="sm" variant="outline" className="ml-auto" onClick={() => markAsTaken(dose.id)}>
              Mark as Taken
            </Button>
          )}
        </div>
      ))}
    </div>
  )
}
