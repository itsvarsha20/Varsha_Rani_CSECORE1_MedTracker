"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { BarChart, Calendar, ClipboardList, Home, Menu, Pill, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { cn } from "@/lib/utils"

const routes = [
  {
    name: "Dashboard",
    path: "/dashboard",
    icon: Home,
  },
  {
    name: "Medications",
    path: "/dashboard/medications",
    icon: Pill,
  },
  {
    name: "Schedule",
    path: "/dashboard/schedule",
    icon: Calendar,
  },
  {
    name: "Medical History",
    path: "/dashboard/history",
    icon: ClipboardList,
  },
  {
    name: "Reports",
    path: "/dashboard/reports",
    icon: BarChart,
  },
]

export function MainNav() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  return (
    <div className="flex items-center">
      <Link href="/dashboard" className="mr-6 flex items-center space-x-2">
        <span className="hidden font-bold sm:inline-block text-xl text-blue-600 dark:text-blue-400">Med-tracker</span>
      </Link>
      <nav className="hidden md:flex items-center space-x-4 lg:space-x-6">
        {routes.map((route) => (
          <Link
            key={route.path}
            href={route.path}
            className={cn(
              "flex items-center text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400",
              pathname === route.path ? "text-blue-600 dark:text-blue-400" : "text-muted-foreground",
            )}
          >
            <route.icon className="h-4 w-4 mr-2" />
            {route.name}
          </Link>
        ))}
      </nav>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild className="md:hidden">
          <Button variant="ghost" size="icon" className="ml-2">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[240px] sm:w-[300px]">
          <div className="flex items-center justify-between">
            <Link href="/dashboard" className="flex items-center space-x-2" onClick={() => setOpen(false)}>
              <span className="font-bold text-xl text-blue-600 dark:text-blue-400">Med-tracker</span>
            </Link>
            <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
              <X className="h-5 w-5" />
              <span className="sr-only">Close menu</span>
            </Button>
          </div>
          <nav className="flex flex-col gap-4 mt-8">
            {routes.map((route) => (
              <Link
                key={route.path}
                href={route.path}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center py-2 text-sm font-medium transition-colors hover:text-blue-600 dark:hover:text-blue-400",
                  pathname === route.path ? "text-blue-600 dark:text-blue-400" : "text-muted-foreground",
                )}
              >
                <route.icon className="h-4 w-4 mr-2" />
                {route.name}
              </Link>
            ))}
          </nav>
        </SheetContent>
      </Sheet>
    </div>
  )
}
