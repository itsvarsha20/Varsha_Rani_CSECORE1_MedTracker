"use client"

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "@/components/ui/chart"

// Sample data for the chart
const data = [
  {
    name: "Mon",
    taken: 3,
    missed: 0,
  },
  {
    name: "Tue",
    taken: 2,
    missed: 1,
  },
  {
    name: "Wed",
    taken: 3,
    missed: 0,
  },
  {
    name: "Thu",
    taken: 2,
    missed: 1,
  },
  {
    name: "Fri",
    taken: 3,
    missed: 0,
  },
  {
    name: "Sat",
    taken: 2,
    missed: 0,
  },
  {
    name: "Sun",
    taken: 3,
    missed: 0,
  },
]

export function WeeklyProgressChart() {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} />
        <Tooltip />
        <Bar dataKey="taken" name="Taken" fill="#4f46e5" radius={[4, 4, 0, 0]} className="fill-primary" />
        <Bar dataKey="missed" name="Missed" fill="#ef4444" radius={[4, 4, 0, 0]} className="fill-red-500" />
      </BarChart>
    </ResponsiveContainer>
  )
}
