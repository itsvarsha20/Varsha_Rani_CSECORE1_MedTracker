import type React from "react"

export const Line = () => <></>
export const LineChart = () => <></>
export const CartesianGrid = () => <></>
export const ResponsiveContainer = ({ children }: { children: React.ReactNode }) => <>{children}</>
export const Tooltip = () => <></>
export const XAxis = () => <></>
export const YAxis = () => <></>
export const Cell = () => <></>
export const Pie = () => <></>
export const PieChart = () => <></>
export const Legend = () => <></>
export const Bar = () => <></>
export const BarChart = () => <></>
